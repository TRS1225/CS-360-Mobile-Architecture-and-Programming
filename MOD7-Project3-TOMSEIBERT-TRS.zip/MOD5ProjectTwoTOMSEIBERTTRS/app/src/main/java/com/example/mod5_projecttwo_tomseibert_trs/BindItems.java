package com.example.mod5_projecttwo_tomseibert_trs;

// SNHU
// CS 360: Mobile Architecture and Programming
// STUDENT NAME: Thomas Seibert
// MOD 7 - Project Three
// this class is an adapter which displays the list of inventory items on the recyclerview.

//import
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import java.util.ArrayList;

// define BindItems class
public class BindItems extends RecyclerView.Adapter<BindItems.ItemViewHolder>
{
    // declare variables
    private final ArrayList<Item> itemList; // list of items to display

    // constructor initializes item list
    public BindItems(ArrayList<Item> itemList)
    {
        this.itemList = itemList;
    }

    // create new views
    @NonNull
    @Override
    public ItemViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType)
    {
        // inflate item layout for each item in datagrid
        View view = LayoutInflater.from(parent.getContext()).
                inflate(R.layout.item_layout, parent, false);
        return new ItemViewHolder(view);
    }

    // replace contents of a view
    @Override
    public void onBindViewHolder(@NonNull ItemViewHolder holder, int position)
    {
        // get current item and set its data to views
        Item currentItem = itemList.get(position);
        holder.itemName.setText(currentItem.getItemName());
        holder.quantity.setText(String.valueOf(currentItem.getQuantity()));
        holder.date.setText(currentItem.getDate());
    }

    // return size of item list
    @Override
    public int getItemCount()
    {
        return itemList.size();
    }

    // hold views for each item
    public static class ItemViewHolder extends RecyclerView.ViewHolder
    {
        // declare variables
        TextView itemName; // textview for item name
        TextView quantity; // textview for item quantity
        TextView date;     // textview for item date

        // constructor to initialize views
        public ItemViewHolder(@NonNull View itemView)
        {
            super(itemView);
            itemName = itemView.findViewById(R.id.ItemName);
            quantity = itemView.findViewById(R.id.Quantity);
            date = itemView.findViewById(R.id.Date);
        }
    }
}
