package com.example.mod5_projecttwo_tomseibert_trs;

// SNHU
// CS 360: Mobile Architecture and Programming
// STUDENT NAME: Thomas Seibert
// MOD 7 - Project Three
// this is a class which builds inventory item objects.

// define Item class
public class Item
{
    // declare variables
    private final String itemName; // name of item
    private final int quantity;     // quantity of item
    private final String date;      // date of item

    // constructor initializes item
    public Item(String itemName, int quantity, String date)
    {
        this.itemName = itemName;
        this.quantity = quantity;
        this.date = date;
    }

    // get item name
    public String getItemName()
    {
        return itemName;
    }

    // get item quantity
    public int getQuantity()
    {
        return quantity;
    }

    // get item date
    public String getDate()
    {
        return date;
    }
}
