package com.example.mod5_projecttwo_tomseibert_trs;

// SNHU
// CS 360: Mobile Architecture and Programming
// STUDENT NAME: Thomas Seibert
// MOD 7 - Project Three
// this is a class to manage database operations (CRUD) for the inventory app.

// import
import android.annotation.SuppressLint;
import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

// define ManageDatabase class to manage inventory data
public class ManageDatabase extends SQLiteOpenHelper
{
    // declare variables
    private static final String DATABASE_NAME = "inventory.db";
    private static final String TABLE_NAME = "items";
    private static final String COL_2 = "ITEM_NAME";
    private static final String COL_3 = "QUANTITY";
    private static final String COL_4 = "DATE";
    private static final String USER_TABLE_NAME = "users";
    private static final String USER_COL_2 = "USERNAME";
    private static final String USER_COL_3 = "PASSWORD";
    private static final int DATABASE_VERSION = 7;

    // constructor to create database
    public ManageDatabase(Context context)
    {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    // create tables
    @Override
    public void onCreate(SQLiteDatabase db)
    {
        // create user table
        db.execSQL("CREATE TABLE " + USER_TABLE_NAME +
                " (ID INTEGER PRIMARY KEY AUTOINCREMENT, USERNAME TEXT, PASSWORD TEXT)");

        // create inventory items table
        db.execSQL("CREATE TABLE "
                + TABLE_NAME +
                " (ID INTEGER PRIMARY KEY AUTOINCREMENT, ITEM_NAME TEXT, QUANTITY INTEGER, DATE TEXT)");
    }

    // if they already exist, drop the tables
    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion)
    {
        db.execSQL("DROP TABLE IF EXISTS " + USER_TABLE_NAME);
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_NAME);
        onCreate(db);
    }

    // insert new item data into database
    public boolean insertData(String itemName, int quantity, String date)
    {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();

        // put item details into table
        contentValues.put(COL_2, itemName);
        contentValues.put(COL_3, quantity);
        contentValues.put(COL_4, date);
        long result = db.insert(TABLE_NAME, null, contentValues);

        // true if item was created
        return result != -1;
    }

    //  delete item from database using its name
    public boolean deleteData(String itemName)
    {
        SQLiteDatabase db = this.getWritableDatabase();

        // return
        return db.delete(TABLE_NAME, "ITEM_NAME=?",
                new String[]{String.valueOf(itemName)}) > 0; // returns true if item is deleted
    }

    // update an item in the database
    public boolean updateData(String itemName, int quantity, String date)
    {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();

        // put item details into table
        contentValues.put(COL_2, itemName);
        contentValues.put(COL_3, quantity);
        contentValues.put(COL_4, date);

        return db.update(TABLE_NAME, contentValues,
                "ITEM_NAME=?", new String[]{String.valueOf(itemName)}) > 0;
                // returns true if item is updated
    }

    // read all entries from database
    public Cursor getAllData()
    {
        SQLiteDatabase db = this.getReadableDatabase();
        return db.rawQuery("SELECT * FROM "
                + TABLE_NAME, null); // returns a cursor with all items
    }

    // check if user exists in database
    public boolean checkUser(String username, String password)
    {
        SQLiteDatabase db = this.getReadableDatabase();
        @SuppressLint("Recycle") Cursor cursor = db.rawQuery("SELECT * FROM "
                + USER_TABLE_NAME +
                " WHERE USERNAME=? AND PASSWORD=?", new String[]{username, password});
        boolean exists = cursor.getCount() > 0;
        cursor.close();
        return exists; // returns true if user exists
    }

    // create user login
    public boolean createUserLogin(String username, String password)
    {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();

        // put username and password into users table
        contentValues.put(USER_COL_2, username);
        contentValues.put(USER_COL_3, password);
        long result = db.insert(USER_TABLE_NAME, null, contentValues);

        // true if user was created successfully
        return result != -1;
    }
}
