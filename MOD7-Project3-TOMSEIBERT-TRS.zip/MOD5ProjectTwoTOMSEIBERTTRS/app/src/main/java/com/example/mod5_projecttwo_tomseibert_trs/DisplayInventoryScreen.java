package com.example.mod5_projecttwo_tomseibert_trs;

// SNHU
// CS 360: Mobile Architecture and Programming
// STUDENT NAME: Thomas Seibert
// MOD 7 - Project Three
// this class handles the inventory database screen functionality.

//import
import android.annotation.SuppressLint;
import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import java.util.ArrayList;

// define DisplayInventoryScreen class
public class DisplayInventoryScreen extends AppCompatActivity
{

    // declare variables
    private RecyclerView recyclerView; // display items in grid
    private BindItems adapter; // adapter to bind data to RecyclerView
    private ArrayList<Item> itemList; // list to hold inventory items
    private EditText editItemName, editQuantity, editDate; // input fields for items
    private Button btnAddItem, btnDeleteItem, btnNavigateToSMS; // buttons

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_database);

        // init RecyclerView
        recyclerView = findViewById(R.id.DataGrid);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));

        // init item list & load entries
        itemList = new ArrayList<>();

        // init adapter with item list
        adapter = new BindItems(itemList);
        recyclerView.setAdapter(adapter);

        // load items from database
        loadItemsFromDatabase();

        // init input fields & buttons
        editItemName = findViewById(R.id.ItemName);
        editQuantity = findViewById(R.id.Quantity);
        editDate = findViewById(R.id.Date);
        btnAddItem = findViewById(R.id.AddInventoryButton);
        btnDeleteItem = findViewById(R.id.DeleteInventoryButton);
        btnNavigateToSMS = findViewById(R.id.NavigateToSMS);

        // button for adding items
        btnAddItem.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v)
            {
                addItemToInventory();
            }
        });

        // button for deleting items
        btnDeleteItem.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v)
            {
                deleteItemFromInventory();
            }
        });

        // button for navigation
        btnNavigateToSMS.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v)
            {
                Intent intent = new Intent(DisplayInventoryScreen.this,
                        NotificationsCode.class);
                startActivity(intent);
            }
        });
    }

    // load items from database into itemList
    @SuppressLint("NotifyDataSetChanged")
    private void loadItemsFromDatabase()
    {
        // clear item list
        itemList.clear();

        // declare instance of ManageDatabase class
        ManageDatabase myDb = new ManageDatabase(this);

        // read function call
        Cursor cursor = myDb.getAllData();

        if (cursor != null && cursor.moveToFirst())
        {
            // use do while loop to get first item on list
            // get item name, quantity, date
            do {
                @SuppressLint("Range") String itemName = cursor.getString(cursor.getColumnIndex("ITEM_NAME"));
                @SuppressLint("Range") int quantity = cursor.getInt(cursor.getColumnIndex("QUANTITY"));
                @SuppressLint("Range") String date = cursor.getString(cursor.getColumnIndex("DATE"));

                // add item to itemList
                itemList.add(new Item(itemName, quantity, date));
            }
            while (cursor.moveToNext());
            cursor.close();
        }

        // if adapter is not empty
        if (adapter != null)
        {
            // notify the adapter that the data has changed
            adapter.notifyDataSetChanged();
        }
    }

    // add item to the inventory
    private void addItemToInventory()
    {
        // declare relevant strings
        String itemName = editItemName.getText().toString();
        String quantityStr = editQuantity.getText().toString();
        String date = editDate.getText().toString();

        // validate user input
        if (itemName.isEmpty() || quantityStr.isEmpty() || date.isEmpty())
        {
            Toast.makeText(DisplayInventoryScreen.this,
                    "Field cannot be empty.", Toast.LENGTH_SHORT).show();
            return;
        }

        // quantity to integer
        int quantity = Integer.parseInt(quantityStr);

        // define conditional variable
        boolean newData;

        // create new entry in database
        try (ManageDatabase myDb = new ManageDatabase(this))
        {
            newData = myDb.insertData(itemName, quantity, date);
        }

        // if added item
        if (newData)
        {
            loadItemsFromDatabase();

            Toast.makeText(DisplayInventoryScreen.this,
                    "Item added successfully.", Toast.LENGTH_SHORT).show();

            // after adding item, clear fields
            clearInputFields();
        }
        // if didn't add item
        else
        {
            Toast.makeText(DisplayInventoryScreen.this,
                    "Failed to add item.", Toast.LENGTH_SHORT).show();
        }
    }

    // delete item from inventory
    private void deleteItemFromInventory()
    {
        // declare relevant string
        String itemName = editItemName.getText().toString();


        // create instance
        try (ManageDatabase myDb = new ManageDatabase(this))
        {
            // condition variable
            boolean dataDeleted = myDb.deleteData(itemName);

            // if item was deleted from database
            if (dataDeleted)
            {
                // remove the item from itemList
                // iterate thru itemList for item
                for (int i = 0; i < itemList.size(); i++)
                {
                    if (itemList.get(i).getItemName().equals(itemName))
                    {
                        itemList.remove(i);
                        // exit loop if item is found and deleted
                        break;
                    }
                }

                // let adapter know that dataset has updated
                adapter.notifyDataSetChanged();

                Toast.makeText(DisplayInventoryScreen.this,
                        "item deleted.", Toast.LENGTH_SHORT).show();
            }
            else
            {
                Toast.makeText(DisplayInventoryScreen.this,
                        "item not deleted.", Toast.LENGTH_SHORT).show();
            }
        }
    }

    // clear input fields
    private void clearInputFields() {
        editItemName.setText("");
        editQuantity.setText("");
        editDate.setText("");
    }
}
