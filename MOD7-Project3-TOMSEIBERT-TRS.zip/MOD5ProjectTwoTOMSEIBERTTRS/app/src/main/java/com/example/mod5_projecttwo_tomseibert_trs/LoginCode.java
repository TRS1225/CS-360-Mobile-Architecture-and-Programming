package com.example.mod5_projecttwo_tomseibert_trs;

// SNHU
// CS 360: Mobile Architecture and Programming
// STUDENT NAME: Thomas Seibert
// MOD 7 - Project Three
// this is a class to handle the login screen functionality.

// import
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

// define LoginCode class
public class LoginCode extends AppCompatActivity
{
    // declare UI and database variables
    ManageDatabase myDb;
    EditText editUsername, editPassword;
    Button btnLogin, btnCreateAccount;

    // initialize activity
    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        // set layout for activity
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        // declare variables
        myDb = new ManageDatabase(this);
        editUsername = findViewById(R.id.Username);
        editPassword = findViewById(R.id.Password);
        btnLogin = findViewById(R.id.LoginButton);
        btnCreateAccount = findViewById(R.id.CreateAccountButton);

        // set up login button click listener
        btnLogin.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v)
            {
                // get username & password from input prompts
                String username = editUsername.getText().toString();
                String password = editPassword.getText().toString();

                // validate user input
                if (username.isEmpty() || password.isEmpty())
                {
                    Toast.makeText(LoginCode.this,
                            "enter both username and password.", Toast.LENGTH_SHORT).show();
                    return; // exit function if inputs are empty
                }

                // check the user exists in database
                if (myDb.checkUser(username, password))
                {
                    // if login successful
                    Toast.makeText(LoginCode.this,
                            "Login success.", Toast.LENGTH_SHORT).show();

                    // intent to navigate to inventory database screen
                    Intent intent = new Intent(LoginCode.this,
                            DisplayInventoryScreen.class);
                    startActivity(intent); // move to inventory screen upon login
                    // finish();
                }
                else
                {
                    // if login was unsuccessful
                    Toast.makeText(LoginCode.this,
                            "Invalid creds.", Toast.LENGTH_SHORT).show();
                }
            }
        });

        // set up create account button click listener
        btnCreateAccount.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v)
            {
                // get username & password from input prompts
                String username = editUsername.getText().toString();
                String password = editPassword.getText().toString();

                // validate user input
                if (username.isEmpty() || password.isEmpty())
                {
                    Toast.makeText(LoginCode.this,
                            "Enter your username and password.",
                            Toast.LENGTH_SHORT).show();
                    return; // exit function if inputs are empty
                }

                // if username already exists
                if (myDb.checkUser(username, ""))
                {
                    Toast.makeText(LoginCode.this,
                            "username already exists.",
                            Toast.LENGTH_SHORT).show();
                    return; // exit function if username already exists
                }

                // create conditional variable
                boolean newUser = myDb.createUserLogin(username, password);

                // provide positive feedback based on result of new user creation in database
                if (newUser)
                {
                    Toast.makeText(LoginCode.this,
                            "Account creation success.", Toast.LENGTH_SHORT).show();
                }
                else
                {
                    Toast.makeText(LoginCode.this,
                            "Account creation fail.", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }
}