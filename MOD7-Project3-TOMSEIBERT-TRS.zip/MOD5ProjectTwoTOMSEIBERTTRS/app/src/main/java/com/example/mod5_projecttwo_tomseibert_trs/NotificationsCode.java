package com.example.mod5_projecttwo_tomseibert_trs;

// SNHU
// CS 360: Mobile Architecture and Programming
// STUDENT NAME: Thomas Seibert
// MOD 7 - Project Three
// this is a class which handles SMS notification screen functionality.

//import

import android.Manifest;
import android.annotation.SuppressLint;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;

// define NotificationsCode class
public class NotificationsCode extends AppCompatActivity
{

    // declare UI variables
    private static final int SMS_PERMISSION_CODE = 100;
    private TextView permissionStatusLabel;

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_notifications);

        // declare UI variables
        Button backToDatabaseButton = findViewById(R.id.BackToDatabase);
        Button notificationsButton = findViewById(R.id.NotificationsButton);
        permissionStatusLabel = findViewById(R.id.PermissionStatusLabel);

        // update permission status on app start
        updatePermissionStatus();

        // set OnClickListener for button SMS notification button
        notificationsButton.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v)
            {
                // check for SMS permission
                if (ActivityCompat.checkSelfPermission
                        (NotificationsCode.this, Manifest.permission.SEND_SMS)
                        != PackageManager.PERMISSION_GRANTED)
                {
                    // request SMS permission
                    ActivityCompat.requestPermissions
                            (NotificationsCode.this,
                                    new String[]{Manifest.permission.SEND_SMS},
                                    SMS_PERMISSION_CODE);
                }
                else
                {
                    // permission already granted
                    // send SMS
                    sendSMS();
                }
            }
        });

        // set OnClickListener for back to database button
        backToDatabaseButton.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v)
            {
                // this should take user back to inventory screen
                Intent intent = new Intent(NotificationsCode.this,
                        DisplayInventoryScreen.class);
                startActivity(intent);
                finish();
            }
        });
    }

    // send SMS
    private void sendSMS()
    {
        // replace with actual phone number
        String phoneNumber = "5555555555";
        String message = "Inventory low.";
        SmsManager smsManager = SmsManager.getDefault();
        smsManager.sendTextMessage
                (phoneNumber, null, message, null, null);
        Toast.makeText(this, "SMS sent.", Toast.LENGTH_SHORT).show();
    }

    // handle result of the permission request
    @Override
    public void onRequestPermissionsResult
    (int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults)
    {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == SMS_PERMISSION_CODE)
        {
            // check if permission was given
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED)
            {
                // permission granted
                // send SMS
                // update status
                sendSMS();
                updatePermissionStatus();
            }
            else
            {
                // Permission denied
                // show a message
                // update status
                Toast.makeText(this, "No permission.", Toast.LENGTH_SHORT).show();
                updatePermissionStatus();
            }
        }
    }

    // update permission status displayed on screen
    @SuppressLint("SetTextI18n")
    private void updatePermissionStatus()
    {
        // if SMS permission is granted
        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS)
                == PackageManager.PERMISSION_GRANTED)
        {
            // update textview to indicate permission granted
            permissionStatusLabel.setText("Permission Status: Good.");
        }
        else
        {
            // update textview to show permission denied
            permissionStatusLabel.setText("Permission Status: Negative.");
        }
    }
}

